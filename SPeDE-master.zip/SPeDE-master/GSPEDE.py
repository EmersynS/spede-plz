import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from GUI import GSPeDE


def main():
    """Dummy class to enable decent installing"""
    GSPeDE.main()


if __name__ == '__main__':
    main()
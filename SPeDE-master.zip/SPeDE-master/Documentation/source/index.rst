.. SPeDE documentation master file, created by
   sphinx-quickstart on Tue Aug 14 13:05:30 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to SPeDE's documentation!
=================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:
   
   GUI.rst
   Spectrum_Processing.rst



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

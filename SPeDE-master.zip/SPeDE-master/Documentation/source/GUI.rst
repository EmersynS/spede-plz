GUI package
===========

Submodules
----------

GUI.GSPeDE module
-----------------

.. automodule:: GUI.GSPeDE
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: GUI
    :members:
    :undoc-members:
    :show-inheritance:
